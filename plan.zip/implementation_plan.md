# Kai-zen-OS Plan Pointer

The active planning documents now live under `Docs/`.

- Primary plan: `Docs/implementation_plan.md`
- Docs index: `Docs/README.md`

This root file is intentionally minimal to avoid duplicate plans.
