﻿# Core Protocol Index

Use this folder as the baseline governance entrypoint before domain-specific controls.

## Read in this order

1. `core/risk_classification.md`
2. `core/agent_autonomy_and_human_oversight.md`
3. `core/risk_autonomy_matrix.md`
4. `core/requirements_management.md`
5. `core/architecture_design.md`
6. `core/coding_guidelines.md`
7. `core/traceability_and_documentation.md`
8. `core/risk_tier_artifact_matrix.md`

## Supporting references

- `core/developer_onboarding_and_examples.md`
- `core/normative_and_reference_guidance.md`
- `core/governance_parameter_registry.md`

## Runtime handoff

After core setup, continue with:

- `../runtime/README.md`
- `../runtime/use_case_profile_framework.md`

