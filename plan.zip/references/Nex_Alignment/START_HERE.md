# Legacy Entry Redirect

The canonical start point moved to:

- `.AppName/APPNAME.md`

Use `.AppName/APPNAME.md` as the primary entrypoint for agents and developers.
