﻿# Evaluation and Audit Index

Use this folder for advisory evaluation systems, assurance lenses, and audit outputs.

## Advisory evaluation frameworks

1. `evaluation/nap_evaluation_harness.md`
2. `evaluation/multi_lens_evaluation_harness.md`
3. `evaluation/multi_agent_simulation_and_modeling.md`

## Quantitative assurance context

- `evaluation/probabilistic_assurance_and_release_metrics.md`
- `evaluation/probabilistic_assurance_math_appendix.md`
- `evaluation/probabilistic_release_gate_example.md`
- `evaluation/economic_and_performance_risk_modeling.md`

## Audit outputs

- `../audit_outputs/README.md`
- `../audit_outputs/use_case_profile_validation_report.json`
- `../audit_outputs/policy_runtime_parity_report.json`
- `../audit_outputs/executable_simulation_results.json`

## Decision authority reminder

Evaluation artifacts are advisory; runtime authorization remains owned by:

- `../runtime/compliance_runtime_spec.md`
- `../runtime/unified_governance_decision_model.md`

