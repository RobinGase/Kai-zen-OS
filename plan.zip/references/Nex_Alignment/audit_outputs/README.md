# Audit Outputs (Generated)

This directory is intentionally clean for fresh project adoption.

Run these scripts to generate new local evidence artifacts for your project:

- `tools/validate_use_case_profiles.ps1`
- `tools/check_policy_runtime_parity.ps1`
- `tools/run_enforcement_simulations.ps1`
- `tools/run_optional_workflows.ps1`

Typical generated files include:

- `use_case_profile_validation_report.json` - Profile and bundle catalog validation results
- `policy_runtime_parity_report.json` - Policy runtime parity check results
- `executable_simulation_results.json` - Enforcement simulation scenario results
- `optional_workflow_results.json` - Optional workflow integration results

Do not treat previously generated outputs from other projects as authoritative for this one.

