﻿# Runtime and Enforcement Index

Use this folder for deterministic runtime decision ownership and policy execution.

## Authoritative runtime path

1. `runtime/compliance_runtime_spec.md`
2. `runtime/unified_governance_decision_model.md`
3. `runtime/enforcement_and_policy_engine.md`
4. `runtime/enforcement_architecture_and_implementation.md`

## Profile-layer runtime routing

1. `runtime/use_case_profile_framework.md`
2. `../profiles/use_case_profiles.yaml`
3. `../profiles/use_case_bundles.yaml`
4. `../templates/policy_engine_rules.yaml`

## Runtime observability and scoring

- `runtime/telemetry_schema.md`
- `runtime/telemetry_example_streams.md`
- `runtime/compliance_scoring_and_metrics.md`
- `runtime/compliance_telemetry_and_governance_drift.md`

## Validation tools

- `../tools/validate_use_case_profiles.ps1`
- `../tools/check_policy_runtime_parity.ps1`
- `../tools/run_enforcement_simulations.ps1`

