﻿# Safety and Assurance Index

Use this folder for hazard control, verification depth, and fail-closed assurance.

## Safety-first reading path

1. `safety/safety_and_assurance.md`
2. `safety/testing_and_verification.md`
3. `safety/negative_testing_and_red_teaming.md`
4. `safety/formal_verification_and_runtime_proof.md`
5. `safety/runtime_behavioral_contracts.md`
6. `safety/risk_acceptance_and_residuals.md`

## AI and supply-chain safety

- `safety/ai_specific_considerations.md`
- `safety/model_and_data_supply_chain_security.md`
- `safety/evidence_anchor_and_log_integrity.md`

## Escalation and resilience

- `../evaluation/multi_agent_and_emergent_risk.md`
- `safety/operations_and_maintenance.md`

