# Requirements (Spoof)

| Requirement ID | Type | Statement | Verification | Linked Design | Linked Control |
|---|---|---|---|---|---|
| REQ-1 | Functional | Orchestrator publishes scoped work per agent session. | TST-1 | DES-1 | CTL-1 |
| REQ-2 | Functional | Agents request peer review through MCP channel only. | TST-2 | DES-2 | CTL-2 |
| REQ-3 | Functional | Review response includes findings and decision. | TST-3 | DES-3 | CTL-3 |
| REQ-4 | Functional | Telemetry events include required schema fields. | TST-4 | DES-4 | CTL-4 |
| REQ-5 | Assurance | Trace links exist REQ -> DES -> COD -> TST. | TST-5 | DES-5 | CTL-5 |
