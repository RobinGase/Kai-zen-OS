pub mod models;
pub mod repository;

pub use repository::ReportRepository;
