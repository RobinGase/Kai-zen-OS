use crate::db::DbPool;
use anyhow::Result;

#[derive(Clone)]
pub struct ReportRepository {
    pool: DbPool,
}

impl ReportRepository {
    pub fn new(pool: DbPool) -> Self {
        Self { pool }
    }
}
