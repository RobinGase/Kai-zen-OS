# Maps and Routing Index

This folder contains machine-friendly and human-friendly routing assets.

## Files

- `use_case_doc_routes.yaml`: deterministic use-case routing map for tooling and agents.

## Intended use

1. Resolve a profile ID to key documents and validation scripts.
2. Keep routing logic stable across CLI, CI, and agent orchestration.
3. Avoid ad hoc folder selection and reduce protocol drift.
